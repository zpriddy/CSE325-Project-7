/*
 * utils.h
 *
 *  Created on: Dec 4, 2013
 *      Author: zpriddy
 */

#ifndef UTILS_H_
#define UTILS_H_

#include "oct_ledm.h"

void setBit(int, int);

void clearBit(int, int);



int getBit(int, int);
#endif /* UTILS_H_ */

